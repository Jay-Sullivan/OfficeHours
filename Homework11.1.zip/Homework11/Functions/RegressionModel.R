# --------------------------------------
# FUNCTION regression_model
# required packages: none
# description:
# inputs:
# outputs:
########################################
regression_model <- function(DataFrame) {
  # Ensure that necessary columns exist
  if (!all(c("SpeciesRichness", "Abundance") %in% names(DataFrame))) {
    stop("DataFrame must contain both 'SpeciesRichness' and 'Abundance' columns.")
  }

  # Fit linear regression model
  model <- lm(SpeciesRichness ~ Abundance, data = DataFrame)

  # Get summary of the model
  model_summary <- summary(model)

  # Extract R-squared and p-value for Abundance
  r_squared <- model_summary$r.squared
  p_value <- coef(model_summary)[2, "Pr(>|t|)"]  # Directly access p-value of Abundance coefficient

  # Return a list of key statistics
  return(list(
    r_squared = r_squared,
    p_value = p_value,
    coefficients = coef(model),  # Coefficients (intercept and Abundance)
    model_summary = model_summary  # Full summary of the regression
  ))
}

 # end of function regression_model
# --------------------------------------
# regression_model()
