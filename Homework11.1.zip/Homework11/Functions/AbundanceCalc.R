# --------------------------------------
# FUNCTION abundance_calc
# required packages: none
# description: calculate abundance for each year (total numbers of individuals found)
# inputs:
# outputs:
########################################

calculate_abundance <- function(df) {
  return(sum(df$individualCount, na.rm = TRUE))
}

#abundance_calc <- function(cleaned){
# assign parameter defaults
#  abundance <- sum(cleaned$individual_count, na.rm = TRUE)  # Adjust column name as needed
#  return(abundance)
#}
# function body



# return(print('...checking function: abundance_calc()'))
# end of function abundance_calc
# --------------------------------------
# abundance_calc()
