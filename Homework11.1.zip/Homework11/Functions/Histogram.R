# --------------------------------------
# FUNCTION histogram
# required packages: none
# description:
# inputs:
# outputs:
########################################
histogram <- function(cleaned_data, abundance_col = "Abundance", richness_col = "SpeciesRichness", output_path = "output/") {

  # Check if the columns exist in the data
  if (!(abundance_col %in% names(cleaned_data))) {
    stop(paste("Column", abundance_col, "not found in the data"))
  }
  if (!(richness_col %in% names(cleaned_data))) {
    stop(paste("Column", richness_col, "not found in the data"))
  }

  # Histogram for Species Richness
  p <- ggplot(cleaned_data, aes_string(x = richness_col)) +
    geom_histogram(fill = "blue", bins = 30, color = "black") +
    theme_minimal() +
    labs(title = paste("Histogram of", richness_col),
         x = richness_col,
         y = "Frequency")

  # Save Species Richness histogram
  ggsave(filename = "SpeciesRichness.pdf", plot = p, path = output_path)

  # Histogram for Abundance
  g <- ggplot(cleaned_data, aes_string(x = abundance_col)) +
    geom_histogram(fill = "red", bins = 30, color = "black") +
    theme_minimal() +
    labs(title = paste("Histogram of", abundance_col),
         x = abundance_col,
         y = "Frequency")

  # Save Abundance histogram
  ggsave(filename = "Abundance.pdf", plot = g, path = output_path)

  # Print completion message
  cat("Histograms saved to", output_path, "\n")
}

# function body
 # end of function histogram
# --------------------------------------
# histogram()
