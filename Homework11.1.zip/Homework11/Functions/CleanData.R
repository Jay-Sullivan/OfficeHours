# --------------------------------------
# FUNCTION clean_data
# required packages: none
# description: Leave only useful information
# inputs: total data
# outputs: Everything except N.A.
########################################
clean_data <- function(data) {
  # Columns to remove
  unwanted_cols <- c("clusterCode", "identificationHistoryID")

  # Remove those columns if they exist in the data
  data <- data[, !(names(data) %in% unwanted_cols)]

  # Remove rows where pointCountMinute is NA
  if ("pointCountMinute" %in% names(data)) {
    data <- data[!is.na(data$pointCountMinute), ]
  }

  return(data)
} # end of function clean_data
# --------------------------------------
# clean_data()
