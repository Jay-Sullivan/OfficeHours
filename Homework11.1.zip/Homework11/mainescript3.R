library(ggplot2)
library(upscaler)
library(devtools)
install_github("ngotelli/upscaler")



# Set the working directory
setwd("~/Desktop/Homework11")
main_folder <- "NEON_count-landbird"
year_folders <- list.dirs(main_folder, full.names = TRUE, recursive = FALSE)
source_batch("Functions")


# Initialize an empty data frame to store results
summary_df <- data.frame(File = character(),
                         Year = numeric(),
                         Abundance = numeric(),
                         SpeciesRichness = numeric(),
                         stringsAsFactors = FALSE)

# Loop through each folder in the year_folders
for (folder in year_folders) {
  # List all countdata CSV files in the folder, matching the pattern
  count_files <- list.files(folder, pattern = "countdata.*\\.csv$", full.names = TRUE)

  # Skip the folder if no countdata files are found
  if (length(count_files) == 0) {
    cat("No countdata files found in folder:", folder, "\n")
    next  # Skip this folder and continue to the next one
  }

  # Iterate through each of the countdata files (although typically there should only be one)
  for (file in count_files) {
    cat("Reading file:", file, "\n")  # Debugging: print the file being processed

    # Read the CSV file
    df <- tryCatch({
      read.csv(file)
    }, error = function(e) {
      cat("Error reading file:", file, "\n")
      return(NULL)  # Return NULL in case of error
    })

    # Skip if reading the file failed
    if (is.null(df)) next

    # Clean the data
    df_clean <- clean_data(df)

    # Extract the year from the file name
    year <- extract_year(file)

    # Calculate abundance and species richness
    abundance <- calculate_abundance(df_clean)
    richness <- calculate_species_richness(df_clean)

    # Add the results to the summary data frame
    summary_df <- rbind(summary_df, data.frame(
      File = basename(file),
      Year = year,
      Abundance = abundance,
      SpeciesRichness = richness
    ))
  }
}

# Save summary statistics to CSV
if (!dir.exists("output")) dir.create("output")
write.csv(summary_df, "output/summary_statistics.csv", row.names = FALSE)

# Run regression model
regression <- regression_model(summary_df)
write.csv(regression, "output/regression_summary.csv", row.names = TRUE)

# Generate histograms for Abundance and Species Richness
build_histogram(summary_df, "Abundance", "output/abundance_histogram.png")
build_histogram(summary_df, "SpeciesRichness", "output/species_richness_histogram.png")

cat("All processing complete.\n")

