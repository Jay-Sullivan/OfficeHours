# Loading packages
library(devtools)
install_github("ngotelli/upscaler")
library(upscaler)
library(ggplot2)
#add_folder("Functions") # adds function folder

setwd("/Users/apple/Desktop/Homework11")
wd <- getwd()


# calls in data
main_folder <- "NEON_count-landbird"
year_folders <- list.dirs(main_folder, full.names = TRUE, recursive = FALSE)

source_batch("Functions")

# Delete?
cleaned_data_folder <- file.path(wd,"CleanedData")
all_countdata_files <- list()

yearly_data <- data.frame()

# Go through year folders and read data files
for (year_folder in year_folders){
  countdata_files <- list.files(year_folder, pattern = "countdata.*\\.csv$", full.names = TRUE)

for (file in countdata_files){
    print(file)
    data <- read.csv(file)
    file_name <- basename(file)
    all_countdata_files[[file_name]] <- list(data = data, file = file)
  }
}
#takes the data from the count data files
# all_countdata_files[[file_name]] <- data


## function creation
# build_function(c("clean_data","extract_year","abundance_calc","richness_calc","regression_model","histogram"))
# already done

 # tells where functions are

#Calls in function
clean_data(data)
cleaned <- clean_data(data)

list.files() # folder path, need to move out of folders
# combination of get working directory and set directory
years <- c()
for (i in list.files("~Desktop/HomeWork11/CleanedData")) { # Need a cleandata file
  extractedyears <- extract_year(i)
  years <- c(years, extractedyears)
}
# DataFrame <- cbind(DataFrame, Year = years)
# Below is incorrect

extract_year(data)


abundance_calc(cleaned)


richness_calc <- c()
for (i in list.files("")) {
  richness <- richness_calc(i)
  values <- c(values, richness)
}
print(richness_calc)


regresion <- data.frame(regression_model(cleaned))


histogram <- histogram(cleaned)


