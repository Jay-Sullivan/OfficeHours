library(devtools)
library(upscaler)
library(ggplot2)

setwd("~/Desktop/Homework11")  # Make sure this is the right path
wd <- getwd()

main_folder <- "NEON_count-landbird"
folders <- list.files(wd)

source_batch("Functions")  # Loads all your functions

# Initialize storage for results
yearly_data <- data.frame()

for (i in folders[3:12]) {
  year_folder_path <- file.path(main_folder, i)
  csv_files <- list.files(year_folder_path, pattern = "countdata.*\\.csv$", full.names = TRUE)

  for (file in csv_files) {
    data <- read.csv(file)
    cleaned <- clean_data(data)

    year <- extract_year(file)
    abundance <- abundance_calc(cleaned)
    richness <- richness_calc(cleaned)

    yearly_data <- rbind(yearly_data, data.frame(
      year = year,
      abundance = abundance,
      richness = richness
    ))
  }
}

# Save cleaned/processed data for inspection
write.csv(yearly_data, file = "output/yearly_data.csv", row.names = FALSE)

# Run regression
regression_summary <- regression_model(yearly_data)
write.csv(regression_summary, "output/regression_summary.csv", row.names = FALSE)

# Create histograms
histogram(yearly_data, "abundance", "output/abundance_histogram.png")
histogram(yearly_data, "richness", "output/richness_histogram.png")

cat("Analysis complete.\n")
