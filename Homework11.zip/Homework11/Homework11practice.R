library(devtools)
install_github("ngotelli/upscaler")
library(upscaler)

add_folder("yearly_data")
add_folder("graphs")

#build function
#look at data, extract, plot
# do this to every folder through
# data set, go through each folder, count data, stats, show output.
# get stats and plots functions we make.
main_folder <- "NEON_count-landbird"

year_folders <- list.dirs(main_folder, full.names = TRUE, recursive = FALSE)

all_countdata_files <- list()

for (year_folder in year_folders){
  countdata_files <- list.files(year_folder, pattern = "countdata.*\\.csv$", full.names = TRUE)

  for (file in countdata_files){
    data <- read.csv(file)

    file_name <- basename(file)
    all_countdata_files[[file_name]] <- data
  }
}

## function



