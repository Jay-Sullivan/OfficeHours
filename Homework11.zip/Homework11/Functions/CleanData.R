# --------------------------------------
# FUNCTION clean_data
# required packages: none
# description: Leave only useful information
# inputs: total data
# outputs: Everything except N.A.
########################################
clean_data <- function(data) {
  #deleting unwanted rows
  dele <- c("clusterCode", "identificationHistoryID")
#cleaned_data <- na.omit()
  data <- data[, !(names(data) %in% dele)]
cleaned_data <- data[!(is.na(data$pointCountMinute)), ]
return(cleaned_data)


} # end of function clean_data
# --------------------------------------
# clean_data()
