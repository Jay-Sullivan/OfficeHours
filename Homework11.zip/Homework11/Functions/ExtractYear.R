# --------------------------------------
# FUNCTION extract_year
# required packages: none
# description: Get year from file name
# inputs: cleaned number data
# outputs: year
########################################
extract_year <- function(data){
  # assign parameter defaults
  year <- sub(".*countdata\\.(\\d{4}-\\d{2})\\.basic.*", "\\1", data)

  return(year)
}

# function body



return(print('...checking function: extract_year()'))

 # end of function extract_year
# --------------------------------------
# extract_year()
