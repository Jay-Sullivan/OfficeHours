# --------------------------------------
# FUNCTION richness_calc
# required packages: none
# description:
# inputs:
# outputs:
########################################
richness_calc <- function(cleaned_data){
# assign parameter defaults
  df <- read.csv(cleaned_data)
  length(unique(df$scientificName))
}

# function body



return(print('...checking function: richness_calc()'))

 # end of function richness_calc
# --------------------------------------
# richness_calc()
