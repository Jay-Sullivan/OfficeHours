# --------------------------------------
# FUNCTION histogram
# required packages: none
# description:
# inputs:
# outputs:
########################################
histogram <- function(cleaned){
  #data=data.frame(value=data)
  # basic histogram
  p <- ggplot(data, aes(x=value)) +
    geom_histogram(fill = "blue")
  ggsave(filename = "SpeciesRichness.pdf", plot = p, path = "Put in path")

  g <- ggplot(data = cleaned) +
    aes(x = Abundance) +
    geom_histogram(fill = "red")
  ggsave(filename = "Abundance.pdf", plot = g, path = "put in path")

}
# function body
 # end of function histogram
# --------------------------------------
# histogram()
