# --------------------------------------
# FUNCTION regression_model
# required packages: none
# description:
# inputs:
# outputs:
########################################
regression_model <- function(DataFrame){
  model <- lm(SpeciesRichness ~ Abundance, data = DataFrame)
  model_summary <- summary(model)
  r_squared <- model_summary$r.squared
  p_value <- coef(model_summary)[2, 4]
  return(list(r_squared = r_squared, p_value = p_value))
}
 # end of function regression_model
# --------------------------------------
# regression_model()
